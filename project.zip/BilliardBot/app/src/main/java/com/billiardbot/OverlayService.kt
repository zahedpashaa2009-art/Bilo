package com.billiardbot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var cal: Calib
    val capture = Capture()
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var panel: LinearLayout? = null
    private var advView: AdviceView? = null
    private var calView: CalibView? = null
    private var advisor: Advisor? = null
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var tvToggle: TextView
    private lateinit var tvMode: TextView
    private lateinit var tvTrick: TextView
    @Volatile var dbg = false
    private var lastMsg = ""
    private var lastMsgT = 0L

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null) return START_NOT_STICKY
        startFg()
        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        cal = Calib(this)
        setupCapture(code, data)
        advisor = Advisor(this, cal)
        addAdviceView()
        buildPanel()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("bot", "BilliardBot", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "bot").setContentTitle("BilliardBot فعال است")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    @Suppress("DEPRECATION")
    private fun setupCapture(code: Int, data: Intent) {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(code, data)
        projection = mp
        mp.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, ui)
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        val rd = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 3)
        rd.setOnImageAvailableListener({ capture.onImage(it) }, ui)
        reader = rd
        vd = mp.createVirtualDisplay("bb", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, null)
    }

    fun say(m: String) {
        ui.post {
            val now = SystemClock.elapsedRealtime()
            if (m == lastMsg && now - lastMsgT < 4000) return@post
            lastMsg = m; lastMsgT = now
            Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
        }
    }

    fun show(a: Advice?, lines: List<String>) { ui.post { advView?.set(a, lines) } }

    fun showBalls(b: List<Ball>?) { ui.post { advView?.setBalls(b) } }

    fun onAdvisorStopped() { ui.post { if (::tvToggle.isInitialized) tvToggle.text = "▶" } }

    private fun modeText() = when (cal.mode) { 0 -> "1-7"; 1 -> "9-15"; else -> "ALL" }

    private fun trickText() = if (cal.trick) "TRK" else "AUTO"

    /** Full-screen layer that lets every touch go through to the game. */
    private fun addAdviceView() {
        val v = AdviceView(this, cal)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp); advView = v
    }

    private fun buildPanel() {
        val dp = resources.displayMetrics.density
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun btn(t: String) = TextView(this).apply {
            text = t; gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(0xCC222222.toInt()); setStroke((2 * dp).toInt(), 0xFF4FC3F7.toInt())
            }
            layoutParams = LinearLayout.LayoutParams((38 * dp).toInt(), (38 * dp).toInt()).apply { bottomMargin = (3 * dp).toInt() }
        }
        tvToggle = btn("▶"); tvToggle.textSize = 18f
        val tvNext = btn("↻"); tvNext.textSize = 18f
        val tvCal = btn("CAL")
        tvMode = btn(modeText())
        tvTrick = btn(trickText())
        val tvDbg = btn("\uD83D\uDC41")
        val tvExit = btn("X")
        col.addView(tvToggle); col.addView(tvNext); col.addView(tvCal); col.addView(tvMode)
        col.addView(tvTrick); col.addView(tvDbg); col.addView(tvExit)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 4; y = (24 * dp).toInt() }

        var dx0 = 0f; var dy0 = 0f; var px0 = 0; var py0 = 0; var moved = false
        tvToggle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx0 = e.rawX; dy0 = e.rawY; px0 = lp.x; py0 = lp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - dx0) + abs(e.rawY - dy0) > 20) {
                        moved = true; lp.x = px0 + (e.rawX - dx0).toInt(); lp.y = py0 + (e.rawY - dy0).toInt()
                        wm.updateViewLayout(col, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) toggle(); true }
                else -> false
            }
        }
        tvNext.setOnClickListener { advisor?.next() }
        tvCal.setOnClickListener { startCalib() }
        tvMode.setOnClickListener { cal.mode = (cal.mode + 1) % 3; cal.save(); tvMode.text = modeText(); advisor?.replan() }
        tvTrick.setOnClickListener { cal.trick = !cal.trick; cal.save(); tvTrick.text = trickText(); advisor?.replan() }
        tvDbg.setOnClickListener {
            dbg = !dbg
            say(if (dbg) "نمایش تشخیص توپ‌ها: روشن (W سفید، S ساده، T راه‌راه، 8)" else "نمایش تشخیص توپ‌ها: خاموش")
            if (!dbg) showBalls(null)
        }
        tvExit.setOnClickListener { stopSelf() }
        wm.addView(col, lp)
        panel = col
    }

    private fun toggle() {
        val a = advisor ?: return
        if (a.running) { a.stop(); tvToggle.text = "▶"; return }
        cal.load()
        if (!cal.ready) { say("اول با دکمه CAL تنظیم کن"); return }
        a.start(); tvToggle.text = "■"
    }

    private fun startCalib() {
        advisor?.stop(); tvToggle.text = "▶"
        panel?.visibility = View.INVISIBLE
        ui.postDelayed({
            val f = capture.grab()
            if (f == null) { say("تصویری از صفحه نیست"); panel?.visibility = View.VISIBLE; return@postDelayed }
            val finish = {
                calView?.let { wm.removeView(it) }; calView = null
                panel?.visibility = View.VISIBLE
                cal.load()
            }
            val v = CalibView(this, f, cal) { finish() }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            wm.addView(v, lp); calView = v
        }, 500)
    }

    override fun onDestroy() {
        advisor?.stop()
        panel?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        advView?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        calView?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        vd?.release(); reader?.close(); capture.close(); projection?.stop()
        super.onDestroy()
    }
}
