package com.billiardbot

import kotlin.math.*

class Pk(val name: String, val pos: P, val axis: P, val side: Boolean)

class Geo(val l: Float, val t: Float, val r: Float, val b: Float, val rad: Float) {
    val il = l + rad; val it = t + rad; val ir = r - rad; val ib = b - rad
    val cy = (t + b) / 2
    val diag = hypot(r - l, b - t)
    val pockets = listOf(
        Pk("بالا-چپ", P(l, t), P(-1f, -1f).norm(), false), Pk("بالا-راست", P(r, t), P(1f, -1f).norm(), false),
        Pk("پایین-چپ", P(l, b), P(-1f, 1f).norm(), false), Pk("پایین-راست", P(r, b), P(1f, 1f).norm(), false),
        Pk("وسط-چپ", P(l, cy), P(-1f, 0f), true), Pk("وسط-راست", P(r, cy), P(1f, 0f), true)
    )
}

class Cand(
    val gh: P, val ball: Ball, val score: Float, val bank: Boolean,
    val d1: Float, val d2: Float, val cutSin: Float, val u: P, val dir: P,
    val pk: Pk, val legs: List<Pair<P, P>>
)

object Planner {
    const val T_DIRECT = 0
    const val T_BANK = 1
    const val T_KISS = 2
    const val T_COMBO = 3
    const val T_KICK = 4
    const val T_SAFE = 5

    private fun segDist(p: P, a: P, b: P): Float {
        val ab = b - a; val l2 = ab.dot(ab)
        if (l2 < 1e-6f) return (p - a).len()
        val t = ((p - a).dot(ab) / l2).coerceIn(0f, 1f)
        return (p - (a + ab * t)).len()
    }

    fun targetsFor(objs: List<Ball>, mode: Int): List<Ball> {
        val own = when (mode) {
            0 -> objs.filter { it.kind == 1 }
            1 -> objs.filter { it.kind == 2 }
            else -> objs.filter { it.kind == 1 || it.kind == 2 }
        }
        return if (own.isEmpty()) objs.filter { it.kind == 3 } else own
    }

    private fun make(cue: P, tb: Ball, aimPt: P, legs: List<Pair<P, P>>, obs: List<P>, g: Geo, pk: Pk, bank: Boolean): Cand? {
        val b = tb.p; val r = g.rad
        val u = (aimPt - b).norm()
        val gh = b - u * (2 * r)
        if (gh.x < g.il - r || gh.x > g.ir + r || gh.y < g.it - r || gh.y > g.ib + r) return null
        val dir = (gh - cue).norm()
        val cos = dir.dot(u)
        if (cos < (if (bank) 0.5f else 0.34f)) return null
        val d1 = (gh - cue).len()
        if (d1 < 2.5f * r) return null
        for (o in obs) if (segDist(o, cue, gh) < 2 * r - 1.5f) return null
        for ((a, c) in legs) for (o in obs) if (segDist(o, a, c) < 2 * r - 1.5f) return null
        val last = legs.last()
        val entry = (last.second - last.first).norm().dot(pk.axis)
        if (entry < 0.5f) return null
        val d2 = legs.sumOf { (it.second - it.first).len().toDouble() }.toFloat()
        val cutSin = sqrt(max(0f, 1f - cos * cos))
        var score = cos.pow(1.3f) * entry / (1f + (d1 + d2) / (g.diag * 0.9f))
        if (pk.side) score *= 0.9f
        if (bank) score *= 0.45f
        return Cand(gh, tb, score, bank, d1, d2, cutSin, u, dir, pk, legs)
    }

    fun cands(cue: P, objs: List<Ball>, targets: List<Ball>, g: Geo): List<Cand> {
        val out = ArrayList<Cand>()
        for (tb in targets) {
            val b = tb.p
            val obs = objs.filter { it !== tb }.map { it.p }
            for (pk in g.pockets) {
                make(cue, tb, pk.pos, listOf(b to pk.pos), obs, g, pk, false)?.let { out.add(it) }
                for (w in 0..3) {
                    val pm = when (w) {
                        0 -> P(2 * g.il - pk.pos.x, pk.pos.y)
                        1 -> P(2 * g.ir - pk.pos.x, pk.pos.y)
                        2 -> P(pk.pos.x, 2 * g.it - pk.pos.y)
                        else -> P(pk.pos.x, 2 * g.ib - pk.pos.y)
                    }
                    val t = when (w) {
                        0 -> (g.il - b.x) / (pm.x - b.x)
                        1 -> (g.ir - b.x) / (pm.x - b.x)
                        2 -> (g.it - b.y) / (pm.y - b.y)
                        else -> (g.ib - b.y) / (pm.y - b.y)
                    }
                    if (t.isNaN() || t <= 0.05f || t >= 0.95f) continue
                    val h = b + (pm - b) * t
                    if (h.x < g.il - 1 || h.x > g.ir + 1 || h.y < g.it - 1 || h.y > g.ib + 1) continue
                    make(cue, tb, pm, listOf(b to h, h to pk.pos), obs, g, pk, true)?.let { out.add(it) }
                }
            }
        }
        return out
    }


    // ------------------------------------------------------------------------------------------
    //  Simulation based planner
    // ------------------------------------------------------------------------------------------

    private val POWERS = floatArrayOf(0.35f, 0.45f, 0.55f, 0.65f, 0.8f, 1f)
    private val SAFE_POWERS = floatArrayOf(0.35f, 0.5f, 0.65f)
    private const val V_FAIL = -0.92f
    private const val BUDGET_NS = 6_000_000_000L

    private class Ctx(val cue: P, val objs: List<Ball>, val mode: Int, val g: Geo, val sim: Sim) {
        val ownLeft = objs.count { own(it.kind) }
        fun own(k: Int) = when (mode) { 0 -> k == 1; 1 -> k == 2; else -> k == 1 || k == 2 }
        fun legalFirst(k: Int) = if (ownLeft > 0) own(k) else k == 3
        fun kindOf(i: Int) = objs[i - 1].kind

        /** The ball this shot "is about": first own ball that falls after a legal first touch (or the 8 when it is time). */
        fun mainOf(res: SimRes): Int {
            if (res.first < 0 || !legalFirst(kindOf(res.first))) return -1
            for (k in res.pocketed.indices) {
                val b = res.pocketed[k]; val kd = kindOf(b)
                if (own(kd) || (kd == 3 && ownLeft == 0)) return b
            }
            return -1
        }

        fun classify(res: SimRes, m: Int): Int {
            if (m < 0) return T_SAFE
            if (res.src[m] > 0) return T_COMBO
            if (res.hits[m] > 0) return T_KISS
            if (res.cueRailsBefore > 0) return T_KICK
            if (res.rails[m] > 0) return T_BANK
            return T_DIRECT
        }
    }

    private class Ev(val v: Float, val ok: Boolean, val main: Int, val entry: Float)
    private class Surv(val ang: Float, val type: Int)
    private class Opt(val ang: Float, val power: Float, val v: Float, val type: Int)
    private class Fin(val adv: Advice, val e: Float, val type: Int, val main: Int)

    private fun rest(res: SimRes, c: Ctx): List<Ball> {
        val out = ArrayList<Ball>()
        for (i in 1 until res.n) if (res.alive[i]) out.add(Ball(res.fx[i], res.fy[i], c.kindOf(i)))
        return out
    }

    private fun clampIn(p: P, g: Geo) = P(p.x.coerceIn(g.il, g.ir), p.y.coerceIn(g.it, g.ib))

    /** How good is the next shot for [mode] from this layout (0 = nothing, ~0.8 = easy). */
    private fun nextBest(cue: P, rest: List<Ball>, mode: Int, g: Geo): Float {
        val tg = targetsFor(rest, mode)
        if (tg.isEmpty()) return 0.3f
        return cands(cue, rest, tg, g).maxOfOrNull { it.score } ?: 0f
    }

    /** Scores a simulated shot. Fouls, scratches, wrong 8-ball, opponent balls, and the position left afterwards all count. */
    private fun eval(res: SimRes, c: Ctx, leave: Boolean, opp: Boolean): Ev {
        var foul = false
        if (res.first < 0) foul = true
        else if (!c.legalFirst(c.kindOf(res.first))) foul = true
        else if (res.pocketed.isEmpty() && !res.railAfter) foul = true
        var v = 0f
        if (res.cueScratch) { foul = true; v -= 3f }
        if (foul) v -= 1.5f
        var own = 0; var oppN = 0; var eight = false
        var main = -1; var entry = 1f
        for (k in res.pocketed.indices) {
            val b = res.pocketed[k]; val kd = c.kindOf(b)
            if (kd == 3) { eight = true; if (main < 0) { main = b; entry = res.entry[k] } }
            else if (c.own(kd)) { own++; if (main < 0 || c.kindOf(main) == 3) { main = b; entry = res.entry[k] } }
            else oppN++
        }
        var ok = false
        if (eight) {
            if (c.ownLeft == 0 && !foul) { v += 12f; ok = true } else v -= 12f
        } else {
            ok = !foul && own > 0
        }
        v += own * 1.0f
        v -= oppN * 0.7f
        if (ok) {
            if (leave && !eight) {
                val rs = rest(res, c)
                val cp = clampIn(P(res.fx[0], res.fy[0]), c.g)
                var l = nextBest(cp, rs, c.mode, c.g)
                for (pk in c.g.pockets) if ((pk.pos - cp).len() < 2.4f * c.g.rad) l -= 0.25f
                v += 0.5f * l
            }
        } else if (!foul) {
            v -= 0.6f
            if (opp && !res.cueScratch) {
                val rs = rest(res, c)
                val om = if (c.mode == 0) 1 else if (c.mode == 1) 0 else 2
                val cp = clampIn(P(res.fx[0], res.fy[0]), c.g)
                v -= 0.8f * nextBest(cp, rs, om, c.g)
            } else v -= 0.3f
        }
        return Ev(v, ok, main, entry)
    }

    private fun angDiff(a: Float, b: Float): Float {
        var d = a - b
        while (d > PI) d -= (2 * PI).toFloat()
        while (d < -PI) d += (2 * PI).toFloat()
        return d
    }

    private fun refl(p: P, w: Int, g: Geo): P = when (w) {
        0 -> P(2 * g.il - p.x, p.y)
        1 -> P(2 * g.ir - p.x, p.y)
        2 -> P(p.x, 2 * g.it - p.y)
        else -> P(p.x, 2 * g.ib - p.y)
    }

    /** Does the straight line a -> b (b is already mirrored) really cross wall w inside the cushion? */
    private fun wallOk(a: P, b: P, w: Int, g: Geo): Boolean {
        val t = when (w) {
            0 -> (g.il - a.x) / (b.x - a.x)
            1 -> (g.ir - a.x) / (b.x - a.x)
            2 -> (g.it - a.y) / (b.y - a.y)
            else -> (g.ib - a.y) / (b.y - a.y)
        }
        if (t.isNaN() || t <= 0.03f || t >= 0.97f) return false
        val h = a + (b - a) * t
        return h.x >= g.il - 1 && h.x <= g.ir + 1 && h.y >= g.it - 1 && h.y <= g.ib + 1
    }

    private fun rot(v: P, a: Float): P = P(v.x * cos(a) - v.y * sin(a), v.x * sin(a) + v.y * cos(a))

    /** Every aim angle that could possibly pocket something: direct, bank (1-2 cushions), combo, kiss, kick. */
    private fun seeds(c: Ctx, targets: List<Ball>): FloatArray {
        val g = c.g; val r = g.rad; val cue = c.cue
        val raw = ArrayList<Float>()
        fun add(aim: P) { val d = aim - cue; if (d.len() > 1.5f * r) raw.add(atan2(d.y, d.x)) }

        for (tb in targets) {
            val b = tb.p
            for (pk in g.pockets) {
                // direct
                val u = (pk.pos - b).norm()
                if (u.len() > 0.5f) add(b - u * (2 * r))
                // bank off one cushion
                for (w in 0..3) {
                    val pm = refl(pk.pos, w, g)
                    if (!wallOk(b, pm, w, g)) continue
                    val u1 = (pm - b).norm()
                    add(b - u1 * (2 * r))
                }
                // bank off two cushions (perpendicular walls)
                for (w1 in 0..3) for (w2 in 0..3) {
                    if (w1 / 2 == w2 / 2) continue
                    val p2 = refl(refl(pk.pos, w2, g), w1, g)
                    if (!wallOk(b, p2, w1, g)) continue
                    val u2 = (p2 - b).norm()
                    add(b - u2 * (2 * r))
                }
                // kick: cue ball hits a cushion first
                val gh = b - u * (2 * r)
                for (w in 0..3) {
                    val gm = refl(gh, w, g)
                    if (wallOk(cue, gm, w, g)) add(gm)
                }
            }
        }
        // combo: ball A drives ball B into the pocket
        for (ta in targets) for (tb in targets) {
            if (ta === tb) continue
            val a = ta.p; val b = tb.p
            for (pk in g.pockets) {
                val u = (pk.pos - b).norm()
                val gB = b - u * (2 * r)
                val dA = (gB - a)
                if (dA.len() < 0.2f * r) continue
                val dirA = dA.norm()
                if (dirA.dot(u) < 0.3f) continue
                add(a - dirA * (2 * r))
            }
        }
        // kiss: ball T glances off another ball K and changes direction into the pocket
        for (tt in targets) {
            val t = tt.p
            for (k in c.objs) {
                if (k === tt) continue
                val kp = k.p
                for (pk in g.pockets) {
                    val dd = (pk.pos - kp).len()
                    if (dd <= 2.1f * r) continue
                    val e = (pk.pos - kp).norm()
                    val th = acos(2f * r / dd)
                    for (s in 0..1) {
                        val tc = kp + rot(e, if (s == 0) th else -th) * (2 * r)
                        val dIn = (tc - t)
                        if (dIn.len() < 0.2f * r) continue
                        val dirIn = dIn.norm()
                        val tang = (pk.pos - tc).norm()
                        if (dirIn.dot(tang) < 0.15f) continue
                        add(t - dirIn * (2 * r))
                    }
                }
            }
        }
        raw.sort()
        val out = ArrayList<Float>()
        for (a in raw) if (out.isEmpty() || abs(a - out.last()) > 0.0015f) out.add(a)
        return out.toFloatArray()
    }

    private fun addSeg(l: ArrayList<Pair<P, P>>, a: P, b: P) { if ((b - a).len() > 1.5f) l.add(a to b) }

    private fun build(c: Ctx, ang: Float, power: Float, tolDeg: Float, type: Int, safeTarget: P?): Advice? {
        val g = c.g; val r = g.rad
        val res = c.sim.run(c.cue, c.objs, ang, power, true)
        val tr = res.trace ?: return null
        val ev = eval(res, c, false, false)
        val m = ev.main
        if (m < 0 && type != T_SAFE) return null
        val cueTr = tr[0]
        val k = res.cuePreCount.coerceIn(1, max(1, cueTr.size))
        val pre = ArrayList<Pair<P, P>>(); val post = ArrayList<Pair<P, P>>()
        for (i in 0 until k - 1) addSeg(pre, cueTr[i], cueTr[i + 1])
        var cnt = 0
        for (i in k - 1 until cueTr.size - 1) { if (cnt >= 2) break; addSeg(post, cueTr[i], cueTr[i + 1]); cnt++ }
        val gh = if (res.first >= 0) P(res.fcx, res.fcy) else (if (cueTr.size > 1) cueTr[1] else c.cue)

        val legs = ArrayList<Pair<P, P>>()
        val marks = ArrayList<P>()
        var pocket: P? = null
        var ballP: P? = safeTarget
        if (m > 0) {
            val mt = tr[m]
            ballP = mt[0]
            for (i in 0 until mt.size - 1) addSeg(legs, mt[i], mt[i + 1])
            for (i in 1 until mt.size - 1) if ((mt[i] - mt[0]).len() > 1.5f) marks.add(mt[i])
            for (q in res.pocketed.indices) if (res.pocketed[q] == m) pocket = g.pockets[res.pocketIdx[q]].pos
        } else if (res.first > 0) ballP = tr[res.first][0]
        val extra = ArrayList<Pair<P, P>>()
        for (i in 1 until res.n) {
            if (i == m) continue
            val t = tr[i]
            if (t.size < 2) continue
            var cn = 0
            for (j in 0 until t.size - 1) { if (cn >= 2) break; if ((t[j + 1] - t[j]).len() > 1.5f * r) { extra.add(t[j] to t[j + 1]); cn++ } }
        }
        val conf = if (type == T_SAFE) 1f else min(1f, max(0.15f, tolDeg / 0.40f))
        val hard = if (type == T_SAFE) "—" else if (conf >= 0.8f) "آسان" else if (conf >= 0.5f) "متوسط" else "سخت"
        var title: String
        if (type == T_SAFE) title = "دفاعی (امن)"
        else {
            val tn = when (type) {
                T_COMBO -> "کمبو"
                T_KISS -> "کیس شات"
                T_KICK -> "کیک (توپ سفید از دیواره)"
                T_BANK -> if (res.rails[m] >= 2) "بانک ۲ دیواره" else "بانک"
                else -> "مستقیم"
            }
            var pn = ""
            for (q in res.pocketed.indices) if (res.pocketed[q] == m) pn = g.pockets[res.pocketIdx[q]].name
            title = tn + " ← جیب " + pn + (if (c.kindOf(m) == 3) " (توپ ۸)" else "")
        }
        var info = ""
        var ownN = 0
        for (b in res.pocketed) if (c.own(c.kindOf(b))) ownN++
        if (ownN >= 2) info = "$ownN توپ خودی می‌افتد"
        return Advice(c.cue, gh, ballP, legs, pocket, power, ang, title, hard, pre, post, extra, marks, tolDeg, info)
    }

    /** Ranked list of advice, best first. [trick] = only combo / kiss / bank / kick shots. */
    fun rank(cue: Ball, balls: List<Ball>, mode: Int, g: Geo, ps: Float, trick: Boolean): List<Advice> {
        val objs = balls.filter { it.kind != 0 }
        if (objs.isEmpty()) return emptyList()
        val r = g.rad

        if (objs.size >= 7) {
            val mx = objs.map { it.x }.average().toFloat(); val my = objs.map { it.y }.average().toFloat()
            if (objs.all { hypot(it.x - mx, it.y - my) < 5.5f * r }) {
                val t = objs.minByOrNull { (it.p - cue.p).len() }!!
                val dir = (t.p - cue.p).norm()
                return listOf(Advice(cue.p, t.p - dir * (2 * r), t.p, emptyList(), null, 1f,
                    atan2(t.y - cue.y, t.x - cue.x), "ضربه شروع (Break)", "—"))
            }
        }

        val t0 = System.nanoTime()
        val sim = Sim(g, ps)
        val c = Ctx(cue.p, objs, mode, g, sim)
        val targets = targetsFor(objs, mode)

        // 1) find every aim that pockets something (tested at full power - geometry only)
        val angs = seeds(c, targets)
        val surv = ArrayList<Surv>()
        for (a in angs) {
            if (System.nanoTime() - t0 > BUDGET_NS / 2) break
            val res = sim.run(c.cue, objs, a, 1f, false)
            val m = c.mainOf(res)
            if (m < 0) continue
            val tp = c.classify(res, m)
            if (trick && tp == T_DIRECT) continue
            var dup = false
            for (s in surv) if (s.type == tp && abs(angDiff(s.ang, a)) < 0.004f) { dup = true; break }
            if (!dup) surv.add(Surv(a, tp))
        }

        // 2) for each, pick the power that gives the best result (including where the cue ball ends up)
        val opts = ArrayList<Opt>()
        for (s in surv) {
            if (System.nanoTime() - t0 > BUDGET_NS * 3 / 4) break
            var best: Opt? = null
            for (pw in POWERS) {
                val ev = eval(sim.run(c.cue, objs, s.ang, pw, false), c, true, false)
                val cur = best
                if (cur == null || ev.v > cur.v) best = Opt(s.ang, pw, ev.v, s.type)
            }
            if (best != null) opts.add(best)
        }
        opts.sortByDescending { it.v }

        // 3) how forgiving is it? sweep the angle, aim at the middle of the working window
        val fins = ArrayList<Fin>()
        val step = (0.12 * PI / 180.0).toFloat()
        for (o in opts) {
            if (fins.size >= 12 || System.nanoTime() - t0 > BUDGET_NS) break
            val oks = BooleanArray(17)
            for (k in -8..8) oks[k + 8] = eval(sim.run(c.cue, objs, o.ang + k * step, o.power, false), c, false, false).ok
            var bs = -1; var bl = 0
            var i = 0
            while (i < 17) {
                if (!oks[i]) { i++; continue }
                var j = i
                while (j + 1 < 17 && oks[j + 1]) j++
                val len = j - i + 1
                val better = if (bs < 0) true
                    else if (len != bl) len > bl
                    else abs((i + j) / 2f - 8f) < abs((2f * bs + bl - 1) / 2f - 8f)
                if (better) { bs = i; bl = len }
                i = j + 1
            }
            if (bl == 0) continue
            val center = (2f * bs + bl - 1) / 2f - 8f
            val ang = o.ang + center * step
            val res = sim.run(c.cue, objs, ang, o.power, false)
            val ev = eval(res, c, true, false)
            if (!ev.ok || ev.main < 0) continue
            val tp = c.classify(res, ev.main)
            if (trick && tp == T_DIRECT) continue
            val tol = bl * 0.12f / 2f
            val q = ((ev.entry - 0.15f) / 0.45f).coerceIn(0.4f, 1f)
            val conf = min(1f, max(0.15f, tol / 0.40f)) * q
            val e = conf * ev.v + (1f - conf) * V_FAIL
            val adv = build(c, ang, o.power, tol * q, tp, null) ?: continue
            fins.add(Fin(adv, e, tp, ev.main))
        }

        // 4) defensive options (only when it makes sense)
        if (!trick || fins.isEmpty()) {
            var bestSafe: Fin? = null
            for (tb in targets) {
                if (System.nanoTime() - t0 > BUDGET_NS) break
                val d = tb.p - cue.p
                val dist = d.len()
                if (dist < 2.5f * r) continue
                val base = atan2(d.y, d.x)
                val off = asin((0.9f * r / dist).coerceIn(0f, 0.9f))
                for (da in floatArrayOf(0f, off, -off)) {
                    for (pw in SAFE_POWERS) {
                        val res = sim.run(c.cue, objs, base + da, pw, false)
                        val ev = eval(res, c, false, true)
                        if (res.first < 0 || res.cueScratch) continue
                        val cur = bestSafe
                        if (cur == null || ev.v > cur.e) {
                            val adv = build(c, base + da, pw, 0f, T_SAFE, tb.p) ?: continue
                            bestSafe = Fin(adv, ev.v, T_SAFE, -1)
                        }
                    }
                }
            }
            val bs = bestSafe
            if (bs != null) fins.add(bs)
        }

        if (trick && fins.isEmpty()) {
            return rank(cue, balls, mode, g, ps, false).map { it.copy(title = "تریک‌شات پیدا نشد؛ " + it.title) }
        }

        fins.sortByDescending { it.e }
        val out = ArrayList<Advice>()
        for (f in fins) {
            if (out.size >= 6) break
            var dup = false
            for (a in out) if (abs(angDiff(a.angle, f.adv.angle)) < 0.017f) { dup = true; break }
            if (!dup) out.add(f.adv)
        }
        return out
    }
}
