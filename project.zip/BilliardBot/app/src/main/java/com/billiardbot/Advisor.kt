package com.billiardbot

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

/** Watches the screen, and after every shot works out the best shot and shows it. Never touches the game. */
class Advisor(private val svc: OverlayService, private val cal: Calib) {
    @Volatile var running = false
    @Volatile private var altIdx = 0
    @Volatile private var list: List<Advice> = emptyList()
    @Volatile private var force = false
    private var th: Thread? = null
    private val hist = ArrayList<List<Ball>>()

    /** Ask for a fresh analysis of the current layout (after mode / trick switch). */
    fun replan() { force = true }

    /** Majority vote over the last few frames so one bad frame can't flip a ball between plain / striped. */
    private fun vote(balls: List<Ball>): List<Ball> {
        hist.add(balls); if (hist.size > 5) hist.removeAt(0)
        val r = cal.ball
        val out = ArrayList<Ball>()
        for (b in balls) {
            val votes = IntArray(4)
            for (h in hist) {
                var bestK = -1; var bd = 0.8f * r
                for (o in h) { val d = hypot(o.x - b.x, o.y - b.y); if (d < bd) { bd = d; bestK = o.kind } }
                if (bestK >= 0) votes[bestK]++
            }
            var k = b.kind
            for (i in 0..3) if (votes[i] > votes[k]) k = i
            out.add(if (k == b.kind) b else Ball(b.x, b.y, k))
        }
        // never more than one cue ball; an extra "white" one is really a striped ball
        var seen = false
        val fixed = ArrayList<Ball>()
        for (b in out) {
            if (b.kind == 0) { if (!seen) { seen = true; fixed.add(b) } else fixed.add(Ball(b.x, b.y, 2)) } else fixed.add(b)
        }
        return fixed
    }

    fun next() { val n = list.size; if (n > 1) altIdx = (altIdx + 1) % n }

    fun start() {
        if (running) return
        running = true
        th = Thread {
            try { loop() } catch (e: InterruptedException) { } catch (e: Exception) { svc.say("خطا: ${e.message}") }
            running = false
            svc.onAdvisorStopped()
        }.also { it.start() }
    }

    fun stop() { running = false; th?.interrupt(); list = emptyList(); svc.show(null, emptyList()); svc.showBalls(null) }

    private fun wrap(d: Double): Double { var x = d; while (x > 180) x -= 360; while (x < -180) x += 360; return x }

    private fun loop() {
        hist.clear()
        var prevSig = Double.NaN; var stable = 0
        var plannedSig = Double.NaN
        while (running) {
            val f = svc.capture.grab()
            if (f == null) { Thread.sleep(300); continue }
            val balls = vote(Vision.detect(f, cal))
            svc.showBalls(if (svc.dbg) balls else null)
            val cue = balls.firstOrNull { it.kind == 0 }
            if (cue == null) {
                list = emptyList(); plannedSig = Double.NaN; prevSig = Double.NaN; stable = 0; hist.clear()
                svc.show(null, listOf("توپ سفید پیدا نشد (ضربه در جریان است؟)"))
                Thread.sleep(400); continue
            }
            val sig = balls.sumOf { it.x.toDouble() + it.y.toDouble() * 1.3 } + balls.size * 10000.0
            stable = if (!prevSig.isNaN() && abs(sig - prevSig) < 1.5) stable + 1 else 0
            prevSig = sig

            if (plannedSig.isNaN() || force || abs(sig - plannedSig) > 3.0) {
                if (stable >= 2) {
                    force = false
                    svc.show(null, listOf(if (cal.trick) "در حال تحلیل تریک‌شات‌ها…" else "در حال تحلیل بهترین ضربه…"))
                    val geo = Geo(cal.l, cal.t, cal.r, cal.b, cal.ball)
                    list = Planner.rank(cue, balls, cal.mode, geo, cal.powerScale, cal.trick)
                    altIdx = 0
                    plannedSig = sig
                } else {
                    list = emptyList()
                    svc.show(null, listOf("در حال حرکت توپ‌ها…"))
                }
            }

            val l = list
            if (l.isNotEmpty()) {
                val a = l[altIdx.coerceIn(0, l.size - 1)]
                val lines = ArrayList<String>()
                lines.add("شات ${altIdx + 1} از ${l.size}:  ${a.title}")
                lines.add("سختی: ${a.hard}   |   قدرت ≈ ${(a.power * 100).roundToInt()}٪" + (if (a.tol > 0f) "   |   دقت ±%.2f°".format(a.tol) else ""))
                if (a.info.isNotEmpty()) lines.add(a.info)
                val cur = Vision.aimAngle(f, cue, cal.ball, a.angle)
                if (cur != null) {
                    val err = wrap(Math.toDegrees(a.angle.toDouble()) - Math.toDegrees(cur.toDouble()))
                    lines.add(if (abs(err) < 0.2) "✔ زاویه دقیق است، بزن!"
                    else "زاویه را %.1f° %s بچرخان".format(abs(err), if (err > 0) "ساعت‌گرد ↻" else "پادساعت‌گرد ↺"))
                }
                svc.show(a, lines)
            }
            Thread.sleep(200)
        }
    }
}
